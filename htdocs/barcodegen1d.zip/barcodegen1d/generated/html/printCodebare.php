
<?php
/* Copyright (C) 2001-2006 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2016 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012 Regis Houssin        <regis.houssin@inodbox.com>
 * Copyright (C) 2013      Cédric Salvador      <csalvador@gpcsolutions.fr>
 * Copyright (C) 2014      Marcos García        <marcosgdf@gmail.com>
 * Copyright (C) 2014      Juanjo Menent        <jmenent@2byte.es>
 * Copyright (C) 2016      Ferran Marcet        <fmarcet@2byte.es>
 * Copyright (C) 2018      Frédéric France      <frederic.france@netlogic.fr>
 * Copyright (C) 2018      Charlene Benke       <charlie@patas-monkey.com>
 * Copyright (C) 2019      Nicolas ZABOURI      <info@inovea-conseil.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   \file       htdocs/barcodegen/generated/html/printCodebareProductInsideCommande.php
 *   \ingroup    fournisseur
 *   \brief      List of purchase orders
 */

require '../../../main.inc.php';


$htmlData = "<div style='width:437;display:block;margin-top:1%' id='print_codebare'>";
$htmlData .= "<style>
    @media print {
        .carte_metisse_style {
            color:white;
            background-color:#000000;
            padding:7px;text-transform:uppercase;
            font-weight:bold;
            position:relative;
            margin-top:-20px;
            font-family: Arial, Helvetica, sans-serif;
        }
   }
   .carte_metisse_style {
            color:white;
            background-color:#000000;
            padding:7px;text-transform:uppercase;
            font-weight:bold;
            position:relative;
            margin-top:-20px;
            font-family: Arial, Helvetica, sans-serif;
        }
</style>";

$sqlGetCommandeFournisseur = "SELECT  cfd.fk_commande, cfd.fk_product, cfd.qty from ".MAIN_DB_PREFIX."commande_fournisseur_dispatch as cfd where cfd.fk_commande in (".$_GET['idCommande'].")";
//echo $sqlGetCommandeFournisseur;    
$resfournsql    = $db->getRows($sqlGetCommandeFournisseur);
    $arrBarCodeProductFourn = [];
    foreach ($resfournsql as $resComF ) {
        
        // product inside commande
        $sqlProd = "select barcode,label,price_ttc from ".MAIN_DB_PREFIX."product where  rowid = ".$resComF->fk_product;
        $resuProd = $db->query($sqlProd);
        $barProd    = $db->fetch_object($resuProd);
        //foreach ($resProd as $barProd) {
        if(!empty($barProd->barcode)){
            //for($i=0;$i<$resComF->qty;$i++) {
            // get commande information
            //$sqlCommande = "SELECT distinct ref from ".MAIN_DB_PREFIX."commande_fournisseur where rowid = ".$resComF->fk_commande;
            //$resuComm = $db->query($sqlCommande);
            //$infoCommande = $db->fetch_object($resuComm);
            //$htmlData .= "<div style='width:437'>Identifiant commande : <b>".$infoCommande->ref."</b></div>";
            $hosts = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME']."/";
            $imgdata = $hosts.DOL_URL_ROOT."/barcodegen1d/generated/html/imageDisplayed.php?codebare=".$barProd->barcode;
            $im = imagecreatefrompng($imgdata);
            ob_start();
            imagepng($im);
            $images = ob_get_contents();
            ob_end_clean();
            $imgDataFromPng =  base64_encode($images);

            $carteMetisse = floor($barProd->price_ttc*0.95*10)/10;

            for($i=0;$i<$resComF->qty;$i++){
                $htmlData .= "<table style='width:437px;height:295'>";
                $htmlData .= "<tr>";
                $htmlData .= "<td colspan=2>";
                $htmlData .= "<p style='font-size:20px;text-transform:uppercase;font-family: Arial, Helvetica, sans-serif;font-weight:bold;'>".$barProd->label."</p>";
                $htmlData .= "</td>";
                $htmlData .= "</tr>";
                $htmlData .= "<tr>";
                $htmlData .= "<td style='width:60%'>";
                $htmlData .= "<img src='data:image/png;base64,".$imgDataFromPng."' style='margin-bottom:25px;'>";
                $htmlData .= "</td>";
                $htmlData .= "<td style='width:40%'>";
                $htmlData .= "<p style='float:right;position:relative;margin-top:104px;font-weight:bold;font-family: Arial, Helvetica, sans-serif;font-size:25px'>".price($barProd->price_ttc). " €"."</p>";
                $htmlData .= "</td>";
                $htmlData .= "</tr>";
                $htmlData .= "<tr>";
                $htmlData .= "<td colspan=2>";
                $htmlData .= "<p class='carte_metisse_style'>Carte metisse: ".price($carteMetisse)." €</p>";
                $htmlData .= "</td>";
                $htmlData .= "</tr>";
                $htmlData .= "</table><div style='margin-top:190px'></div>";
            }
        }
            //}
        //}
    }
$htmlData .= "</div>";
print $htmlData;
?>

<script type="text/javascript">
    var divContents = document.getElementById("print_codebare").innerHTML;
    var printWindow = window.open('', '', 'height=400,width=980');
    printWindow.document.write('<html><head><title>Print DIV Content</title>');
    printWindow.document.write('</head><body><div style="width:437px;">');
    printWindow.document.write(divContents);
    printWindow.document.write('</div></body></html>');
    printWindow.document.close();
    printWindow.print();
</script>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */
    }
     .carte_metisse_style {
            color:white;
            background-color:#000000;
            padding:7px;text-transform:uppercase;
            font-weight:bold;
            position:relative;
            margin-top:-20px;
            font-family: Arial, Helvetica, sans-serif;
        }
         @media print {
        .carte_metisse_style {
            color:white;
            background-color:#000000;
            padding:7px;text-transform:uppercase;
            font-weight:bold;
            position:relative;
            margin-top:-20px;
            font-family: Arial, Helvetica, sans-serif;
        }
   }
</style>
<?php
header("Location: ".DOL_URL_ROOT."/fourn/commande/list.php");
exit;