<?php
$classFile = 'BCGean8.php';
$className = 'BCGean8';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
