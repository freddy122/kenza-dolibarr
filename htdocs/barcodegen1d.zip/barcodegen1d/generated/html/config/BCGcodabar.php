<?php
$classFile = 'BCGcodabar.php';
$className = 'BCGcodabar';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
