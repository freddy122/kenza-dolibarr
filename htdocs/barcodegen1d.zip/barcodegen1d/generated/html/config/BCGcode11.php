<?php
$classFile = 'BCGcode11.php';
$className = 'BCGcode11';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
