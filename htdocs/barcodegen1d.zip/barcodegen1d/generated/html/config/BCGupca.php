<?php
$classFile = 'BCGupca.php';
$className = 'BCGupca';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
