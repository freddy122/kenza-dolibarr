<?php
$classFile = 'BCGupce.php';
$className = 'BCGupce';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
