<?php
$classFile = 'BCGean13.php';
$className = 'BCGean13';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
