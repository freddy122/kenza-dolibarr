This script is NOT FREE. You paid for it.
To see your rights based on your license, please visit
http://www.barcodebakery.com

Ce script n'est PAS GRATUIT. Vous l'avez payé.
Pour voir vos droits dépendamment de votre licence, visitez
http://www.barcodebakery.com
