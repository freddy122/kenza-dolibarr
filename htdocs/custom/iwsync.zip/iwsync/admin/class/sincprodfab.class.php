<?php

class SincProdFab
{
    /**
    * @var DoliDB Database handler.
    */
    public $db;
    
    /**
    * Constructor
    *
    * @param		DoliDB		$db      Database handler
    */
    public function __construct($db)
    {
        $this->db = $db;
    }
    
    /**
     * 
     * @return array
     */
    public function getParentProductFab()
    {
        $sql = "SELECT rowid, label, ref_fab_frs FROM ".MAIN_DB_PREFIX."product WHERE product_type_txt = 'fab' and POSITION('_' IN ref) = 0 order by rowid desc";
        $query = $this->db->query($sql);
        $return = array();

        while ($result = $this->db->fetch_object($query)) {
                $return[$result->rowid] = $result->label."( ".$result->ref_fab_frs." )";
        }
        return $return;
    }
    
}

